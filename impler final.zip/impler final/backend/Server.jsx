
const express = require('express');
const cors = require('cors');
const app = express();
const port = 3001; 

app.use(express.json());
app.use(cors()); 

app.post('/api/placeOrder', (req, res) => {
  const { firstName, lastName, address, cartItems } = req.body;

 
  if (!firstName || !lastName || !address) {
    return res.status(400).json({ success: false, message: 'All fields are required.' });
  }



  console.log('Order placed:', { firstName, lastName, address, cartItems });

  res.status(200).json({ success: true, message: 'Order placed successfully.' });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

const cors = require('cors');
app.use(cors());
