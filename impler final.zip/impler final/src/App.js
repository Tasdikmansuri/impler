import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './component/Navbar/Navbar';

import ShopContextProvider from './component/context/shopcontext';
import Item from './component/item/Item';
import Hero from './component/hero/Hero';
import Shop from './component/pages/Shop';
import  Men  from './component/pages/Men';
import  Women from './component/pages/Women';
import Kids from './component/pages/Kids';
import Product from './component/pages/Product';
import Cart from './component/pages/Cart';
import Loginsingup from './component/pages/Loginsingup';
import Footer from './component/footer/footer';

import men_banner from './component/Assets/banner_mens.png'
import Shopcatagory from './component/pages/Shopcatagory';
import women_banner from './component/Assets/banner_women.png'
import kids_banner from './component/Assets/banner_kids.png'
import Home from '../src/component/Home/Home'


export const App = () => {
    return (
        <Router>
            <div>
               <ShopContextProvider>
                    <Navbar />
                   
                    <Item />
                 
                    <Routes>
                        <Route path='/' element={<Shop />} />
                        <Route path='/Men' element={<Shopcatagory banner={men_banner} catagory="Men" />} />
                        <Route path='/Women' element={<Shopcatagory banner={women_banner} catagory="women" />} />
                        <Route path='/Kids' element={<Shopcatagory banner={kids_banner} catagory="Kids"/>} />
                        <Route path="/" element={<Home />} />
                        <Route path="/product/:productid" element={<Product />} />
                        <Route path='/productid' element={<Product />} />
                        <Route path='/Cart' element={<Cart />} />
                        <Route path='/Login' element={<Loginsingup />} />
                        <Route path='/Home'  element={<Product />} />
                    </Routes>
                   <Footer />
                   </ShopContextProvider>

            </div>
        </Router>
    );
}

export default App;
