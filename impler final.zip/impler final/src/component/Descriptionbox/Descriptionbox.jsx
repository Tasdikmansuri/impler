import React from 'react'
import './Descriptionbox.css'

export const Descriptionbox = () => {
  return (
    <div className='descriptionbox'>
        <div className="descriptionbox-navigator">
            <div className='descriptionbox-nav-box'>Description</div>
            <div className='descriptionbox-nav-box fade'>Rivew</div>
        </div>
        <div className='descriptionbox-discription'>
            <p>
            This is a great product that you will love. It has many features and benefits that make it a must-have item
            </p>
            <p>
            This is a great product that you will love. It has many features and benefits that make it a must-have item
            </p>
        </div>

    </div>
  )
}
