import React, { useContext } from 'react';
import { shopcontext } from '../context/shopcontext';
import Item from '../cartitem/Cartitem';

const Home = () => {
  const { all_product } = useContext(shopcontext);

  return (
    <div>
      <h1>Product List</h1>
      <div className="product-list">
        {all_product.map(product => (
          <Item
            key={product.id}
            id={product.id}
            image={product.image}
            name={product.name}
            new_price={product.newPrice}
            old_price={product.oldPrice}
          />
        ))}
      </div>
    </div>
  );
}

export default Home;
