import React, { useContext, useState } from 'react';
import { shopcontext } from '../context/shopcontext';
import './cartitem.css';

const CartItem = () => {
  const { all_product, cartItem, removeFromCart, getTotalCartAmount } = useContext(shopcontext);

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    address: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form data submitted:', formData);
  };

  const calculateTotal = () => {
    let total = 0;
    all_product.forEach(product => {
      if (cartItem[product.id] > 0 && product.newPrice) {
        total += product.newPrice * cartItem[product.id];
      }
    });
    return total.toFixed(2);
  };

  return (
    <div className='cart-page'>
      <h1>Cart Page</h1>
      <div className='cart-items'>
        <div className='cartitem-formate-main'>
          <p>Product</p>
          <p>Title</p>
          <p>Price</p>
          <p>Quantity</p>
          <p>Remove</p>
        </div>
        <hr />
        {all_product.map((product) => {
          if (cartItem[product.id] > 0) {
            return (
              <div key={product.id}>
                <div className="cartitem-formate cartitem-formate-main">
                  <img src={product.image} alt={product.name} className='carticon-product-icon' />
                  <p>{product.name}</p>
                  <p>${product.newPrice ? product.newPrice.toFixed(2) : 'N/A'}</p>
                  <p>{cartItem[product.id]}</p>
                  <p>${product.newPrice ? (product.newPrice * cartItem[product.id]).toFixed(2) : 'N/A'}</p>
                  <button className='cartitem-remove-icon' onClick={() => removeFromCart(product.id)}>Remove</button>
                </div>
                <hr />
              </div>
            );
          }
          return null;
        })}
        <div className="cartitems-down">
          <h1>Cart Total</h1>
        </div>
        <div className="cartitem-total-item">
          <p>Subtotal</p>
          <p>${calculateTotal()}</p>
        </div>
        <hr />
        <div className="cartitem-total-item">
          <p>Shipping Free</p>
          <p>Free</p>
        </div>
        <hr />
        <div className="cartitem-total-item">
          <h3>Total</h3>
          <h3>${getTotalCartAmount()}</h3>
        </div>
      </div>
      <form className='user-details-form' onSubmit={handleSubmit}>
        <h2>User Details</h2>
        <label>
          First Name:
          <input
            type='text'
            name='firstName'
            value={formData.firstName}
            onChange={handleInputChange}
            required
          />
        </label>
        <label>
          Last Name:
          <input
            type='text'
            name='lastName'
            value={formData.lastName}
            onChange={handleInputChange}
            required
          />
        </label>
        <label>
          Address:
          <input
            type='text'
            name='address'
            value={formData.address}
            onChange={handleInputChange}
            required
          />
        </label>
        <button type='submit'>Submit</button>
      </form>
      <button>Proceed to Checkout</button>
    </div>
  );
};

export default CartItem;
