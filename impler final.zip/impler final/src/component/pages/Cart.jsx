import React from 'react'
import CartItem from '../cartitem/Cartitem';


export const Cart = () => {
  return (
    <div>
    <CartItem />
    </div>
  )
}
export default Cart;