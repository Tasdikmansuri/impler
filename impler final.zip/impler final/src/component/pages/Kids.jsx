import React from 'react'

export const Kids = () => {
  return (
    <div>Kids</div>
  )
}
export default Kids;