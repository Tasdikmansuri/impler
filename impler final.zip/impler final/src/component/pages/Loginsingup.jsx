import React from 'react'

export const Loginsingup = () => {
  return (
    <div>Loginsingup</div>
  )
}
export default Loginsingup;