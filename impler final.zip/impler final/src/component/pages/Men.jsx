import React from 'react'

export const Men = () => {
  return (
    <div>Men</div>
  )
}


export default Men;