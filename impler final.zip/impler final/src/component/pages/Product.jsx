// Product.js
import React, { useContext } from 'react';
import { useParams } from 'react-router-dom';
import { shopcontext } from '../context/shopcontext';
import Breadcrum from '../Breadcrum/Breadcrum';
import { Productdisplay } from '../Productdisplay/Productdisplay';
import { Descriptionbox } from '../Descriptionbox/Descriptionbox';

const Product = () => {
  const { all_product } = useContext(shopcontext);
  const { productid } = useParams();
  const product = all_product.find((e) => e.id === parseInt(productid, 10));

  if (!product) {
    return <div>Product not found</div>;
  }

  return (
    <div>
      <Breadcrum product={product} />
      <Productdisplay product={product} />
      <Descriptionbox />
    </div>
  );
};

export default Product;
