import React from 'react'
import Hero from '../hero/Hero';
import Newcollection from '../Newcollection/Newcollection';
import Popular from '../Popular/Popular';
import Footer from '../footer/footer';

export const Shop = () => {
  return (
    <div>
      <Hero />
      <Popular />
      <Newcollection />
    
   
    </div>
  )
}


export default Shop;
