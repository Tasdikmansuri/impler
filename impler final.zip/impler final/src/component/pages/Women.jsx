import React from 'react'

export const Women = () => {
  return (
    <div>Women</div>
  )
}

export default Women;